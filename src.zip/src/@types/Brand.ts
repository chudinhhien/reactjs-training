export interface Brand {
  name: string,
  count: number,
}
