export interface FilterProps {
  title: string
}
