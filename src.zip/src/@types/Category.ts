export interface Category {
  name: string,
  count: number,
}
